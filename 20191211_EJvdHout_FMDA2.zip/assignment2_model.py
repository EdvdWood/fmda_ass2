import assignment2_functions as fun
